//
//  BigFile.swift
//  SwiftTest
//
//  Created by Thomas Wetmore on 8/29/2014.
//  Last changed on 8/29/2014.
//  Copyright (c) 2014 Deadends Software. All rights reserved.
//

import Foundation

// Instances of this class are large files requiring memory mapped io.
//--------------------------------------------------------------------------------------------------
class BigFile {
    var length: Int
    var count: Int

    // The memory mapped data object holding the data of this big file.
    private var data: NSData?
    private var index: Int

    init (path: String) {
        length = 0
        count = 0
        index = 0
    }

    func nextLine () -> String {
        return "hello"
    }
}

/*
#define CS(s) [(s) cStringUsingEncoding: NSUTF8StringEncoding]

static NSArray* encodings = nil;

{

// The bytes making up the data of this big file.
const Byte* _bytes;
}

// Length of this big file in bytes.
@synthesize length = _length;

// Number of lines read from this big file so far.
@synthesize count = _count;

// Index of next byte to read.
@synthesize index = _start;

// Initialize this big file from a path.
//--------------------------------------------------------------------------------------------------
- (id) initWithPath: (NSString*) path
{
self = [super init];
if (!self) {
return nil;
}

// Create a data object for the file using memory mapped io.
_data = [NSData dataWithContentsOfFile: path
options: NSDataReadingMappedAlways + NSDataReadingUncached
error: nil];

// Initialize the state variables.
_length = [_data length];
_bytes = [_data bytes];
_count = 0;
_start = 0;

return self;
}

// Return the next line from this big file.
//--------------------------------------------------------------------------------------------------
- (NSString*) nextLine
{
// Check if already read the whole file.
if (_start >= _length) {
return nil;
}

// Extract the next line from the data by finding the next new line character.
NSUInteger end = _start;
while (end < _length && _bytes[end] != '\n') {
end++;
}
NSString* line = [[NSString alloc] initWithBytes: _bytes + _start
length: end - _start
encoding: NSUTF8StringEncoding];

// If Unicode encoding didn't work, try a few others.
if (!line) {
for (NSNumber* number in encodings) {
line = [[NSString alloc] initWithBytes: _bytes + _start
length: end - _start
encoding: [number integerValue]];
if (line) {
break;
}
}
}

// Move read cursor ahead to the index of first byte in the next line.
_start = end + 1;
_count++;

// If there isn't a line at this point, return a zero-length string rather than a nil, since
// nil indicates end of file, and this isn't an end of file situation.
if (!line) {
return @"";
}
return line;
}

// Initialize the big file class by setting up the table of alternate encodings.
//--------------------------------------------------------------------------------------------------
+ (void) initialize
{
encodings = @[@(NSISOLatin1StringEncoding),
@(NSWindowsCP1252StringEncoding),
@(NSMacOSRomanStringEncoding),
@(NSASCIIStringEncoding)];
}

@end

*/