//
//  AstroBody.swift
//  SwiftTest
//
//  Created by Thomas Wetmore on 8/21/2014.
//  Last changed on 3/25/2022.
//  Copyright (c) 2014-2022 Deadends Software. All rights reserved.
//

import Darwin // for math functions

// Heliocentric gravitational constant in years and astronomical units;
// heliocentricGravitationalConstant is in seconds and meters.
let hgc_year_au = heliocentricGravitationalConstant*pow(
                        secondsPerYear, 2.0)/pow(astronomicalUnit, 3.0);

// AstroBodies represent objects in the solar system that orbit the sun. They can be used in
// different contexts so not all properties may need be set to meaningful values.
public struct AstroBody : CustomStringConvertible, Positioned, Equatable, Hashable {

    // Stored Instance Properties
    // Intrisic properties, if used.
    public private(set) var name: String             // Name of body. Must be unique for Hashable.
    public private(set) var mass = 0.0               // Mass of body in kilograms, if used.
    public private(set) var radius = 0.0             // Radius of body in meters, if used.
    // Position and velocity Vectors, if used.
    public private(set) var position = Vector.zero   // Position of body in helio coords in AU.
    public private(set) var velocity = Vector.zero   // Velocity of body in helio coords in AU/year.
    // Keplerian orbital elements, if used.
    public private(set) var semimajorAxis = 0.0      // Semi-major axis in AU.
    public private(set) var eccentricity = 0.0       // Orbital eccentricity of body; dimensionless.
    public private(set) var inclination = 0.0        // Inclination from ecliptic plane in radians.
    public private(set) var longAscendingNode = 0.0  // Longitude of ascending node in radians.
    public private(set) var argPeriapsis = 0.0       // Argument of periapsis in radians.
    public private(set) var longPeriapsis = 0.0      // Longitude of periapsis in radians.
    public private(set) var epoch = AstroTime.now()  // Date and time of trueAnomalyAtEpoch.
    public private(set) var trueAnomalyAtEpoch = 0.0 // True anomaly in radians.

    // Computed Instance Properties:
    // Mean anomaly at epoch in radians; requires valid trueAnomalyAtEpoch.
    public var meanAnomalyAtEpoch: Double {
        trueToMeanAnomaly(trueAnomaly: trueAnomalyAtEpoch, eccentricity: eccentricity)
    }
    // Argument of latitude in radians.
    public var argLatitude: Double {
        trueAnomalyAtEpoch + argPeriapsis
    }
    // True longitude in radians.
    public func trueLongitude(trueAnomaly: Double) -> Double {
        trueAnomaly + argPeriapsis + longAscendingNode
    }
    // Apoapsis distance in AU.
    public var apoapsis: Double {
        (1 + eccentricity)*semimajorAxis
    }
    // Periapsis distance in AU.
    public var periapsis: Double {
        (1 - eccentricity)*semimajorAxis
    }
    // Semilatus rectum in AU.
    public var semilatusRectum: Double {
        (1 - eccentricity*eccentricity)*semimajorAxis
    }
    // Orbital period in years; assumes semimajor axis is in AU and body is orbiting the sun.
    public var period: Double {
        twoPi*sqrt(semimajorAxis*semimajorAxis*semimajorAxis/hgc_year_au)
    }
    // Description of body.
    public var description: String {
        var buffer: String = ""
        buffer += "\(name)"
        buffer += " smax:\(semimajorAxis.format(3))"
        buffer += " eccn:\(eccentricity.format(3))"
        buffer += " incl:\(inclination.format(3))"
        buffer += " anod:\(longAscendingNode.format(3))"
        buffer += " aper:\(argPeriapsis.format(3))"
        return buffer
    }

    // Init AstroBody with intrinsic properties. Mass is in kilograms and radius in meters.
    init (name: String, mass: Double, radius: Double) {
        self.name = name
        self.mass = mass
        self.radius = radius
    }

    // Implement hashable protocol. Assumes AstroBodies have unique names.
    public func hash (into hasher: inout Hasher) {
        hasher.combine(name)
    }

    // Set the Keplerian orbital elements of this AstroBody.
    mutating func setElements (semimajorAxis: Double,
                               eccentricity: Double,
                               inclination: Double,
                               longAscendingNode: Double,
                               argPeriapsis: Double,
                               epoch: AstroTime,
                               trueAnomalyAtEpoch: Double) {
        self.semimajorAxis = semimajorAxis
        self.eccentricity = eccentricity
        self.inclination = inclination
        self.longAscendingNode = longAscendingNode
        self.argPeriapsis = argPeriapsis
        self.epoch = epoch
        self.trueAnomalyAtEpoch = trueAnomalyAtEpoch
    }

    // Set the orbital elements of this AstroBody from its position and velocity in AU and AU/year.
    // TODO: This method has not been tested.
    mutating func setElements (primaryMass: Double,
                               g: Double,
                               primaryPosition: Vector,
                               primaryVelocity: Vector) {

        // Get the position and velocity Vectors of this AstroObject relative to its primary.
        let position = self.position - primaryPosition
        let velocity = self.velocity - primaryVelocity
        let radius = position.length  // Distrance from sun.
        let velocitySquared = velocity.square

        // Get the angular momentum Vector, perpendicular to orbital plane.
        let angularMomentum = cross(position, velocity)

        // Get the ascending node Vector, the intersection of the orbital ecliptic planes; if the
        // planes are coplanar this vector is zero.
        let ascendingNode: Vector = cross(Vector.k, angularMomentum)
        let nMagnitude: Double = ascendingNode.length
        let coplanar: Bool = nMagnitude == 0

        // Get the gravitational parameter.
        let mu: Double = g*(mass + primaryMass)

        // Get the eccentricity Vector; its magnitude is the eccentricity; it points to periapsis.
        let eccentricity = (position*(velocitySquared - mu/radius) -
                                        velocity*dot(position, velocity))/mu
        self.eccentricity = eccentricity.length

        // Get semi-latus rectum and semimajor axis of this AstroBody.
        let semiLatusRectum: Double = angularMomentum.square/mu
        semimajorAxis = semiLatusRectum/(1 - self.eccentricity*self.eccentricity)

        // Get orbital inclination; for coplanar orbits this is zero.
        inclination = acos(angularMomentum.z/angularMomentum.length)

        // Get longitude of the ascending node; undefined for coplanar orbits.
        longAscendingNode = acos(ascendingNode.x/nMagnitude)
        if ascendingNode.y < 0 {
            longAscendingNode -= Double.pi
        }

        // Get argument of periapsis; undefined if orbit is circular.
        argPeriapsis = acos(dot(ascendingNode, eccentricity)/nMagnitude/self.eccentricity)
        if eccentricity.z > 0 {
            argPeriapsis -= Double.pi
        }

        // Get longitude of periapsis; undefined if orbit is circular; special formula used if
        //orbit is coplanar.
        if !coplanar {
            longPeriapsis = longAscendingNode + argPeriapsis
        } else {
            longPeriapsis = acos(dot(eccentricity, Vector.i)/self.eccentricity)
        }

        // Get true anomaly at epoch; undefined if orbit is circular.
        trueAnomalyAtEpoch = acos(dot(eccentricity, self.position)/self.eccentricity/radius)
        if dot(position, self.velocity) > 0 {
            trueAnomalyAtEpoch -= Double.pi
        }
    }

    // Set heliocentric coordinates of AstroBody at a specific time. The Keplerian orbital
    // elements must be valid -- semimajorAxis, eccentricity, inclination, longAscendingNode,
    // argPeriapsis, trueAnomalyAtEpoch and epoch.
    public mutating func setHeliocentric (time: AstroTime) {
        // Convenience variables.
        let a = semimajorAxis
        let e = eccentricity
        // Get time since epoch in years.
        let differenceInYears: Double = (time - epoch)/daysPerYear
        // Get mean anomaly since last periapsis passage.
        var meanAnomaly = meanAnomalyAtEpoch + twoPi*differenceInYears/period
        meanAnomaly = fmod(meanAnomaly, twoPi)
        if meanAnomaly < 0.0 {
            meanAnomaly += twoPi
        }
        // Get eccentric anomaly from mean anomaly.
        let eccentricAnomaly = meanToEccentricAnomaly(meanAnomaly: meanAnomaly, eccentricity: e)
        // Get perifocal coordinates.
        let p = a*(cos(eccentricAnomaly) - e)
        let q = a*sqrt(1.0 - e*e)*sin(eccentricAnomaly)
        // Get heliocentric coordinates.
        position = periToEclipticMatrix() * Vector(x: p, y: q, z: 0.0)
    }

    // Return Matrix that rotates the AstroBody's perifocal (pq) coordinates to heliocentric (ijk)
    // coordinates. Requires the body to have longAscendingNode, argPeriapsis, and inclination.
    func periToEclipticMatrix () -> Matrix {
        // Convenience constants.
        let cosAnod = cos(longAscendingNode)
        let sinAnod = sin(longAscendingNode)
        let cosAper = cos(argPeriapsis)
        let sinAper = sin(argPeriapsis)
        let cosIncl = cos(inclination)
        let sinIncl = sin(inclination)
        // Get the 9 elements of the rotation matrix.
        let r11 = cosAnod*cosAper - sinAnod*sinAper*cosIncl
        let r12 = -cosAnod*sinAper - sinAnod*cosAper*cosIncl
        let r13 = sinAnod*sinIncl
        let r21 = sinAnod*cosAper + cosAnod*sinAper*cosIncl
        let r22 = -sinAnod*sinAper + cosAnod*cosAper*cosIncl
        let r23 = -cosAnod*sinIncl
        let r31 = sinAper*sinIncl
        let r32 = cosAper*sinIncl
        let r33 = cosIncl
        // Construct rows of the rotation matrix.
        let row0 = Vector(r11, r12, r13)
        let row1 = Vector(r21, r22, r23)
        let row2 = Vector(r31, r32, r33)
        // Construct rotation matrix from its rows.
        return Matrix(top: row0, mid: row1, bot: row2)
    }
}

// Equivalence relation for bodies. They must have unique names.
public func == (lhs: AstroBody, rhs: AstroBody) -> Bool {
    return lhs.name == rhs.name
}

// Convert mean anomaly to true anomaly.
func meanToTrueAnomaly (meanAnomaly: Double, eccentricity: Double) -> Double {
    eccentricToTrueAnomaly(
        eccentricAnomaly: meanToEccentricAnomaly(meanAnomaly: meanAnomaly,
                                                 eccentricity: eccentricity),
        eccentricity: eccentricity)
}

// Convert mean anomaly to eccentric anomaly by solving Kepler's equation iteratively. This method
// stops after 50 iterations if the eccentric anomaly hasn't converged. No indication of this
// condition is given.
func meanToEccentricAnomaly (meanAnomaly: Double, eccentricity: Double) -> Double {
    let error = 0.000000000000001
    let maxCount = 150
    var estimate0 = 0.0
    var estimate1 = meanAnomaly
    var count = 0
    repeat {
        estimate0 = estimate1
        estimate1 = estimate0 + (meanAnomaly - estimate0
                              + eccentricity*sin(estimate0))/(1.0 - eccentricity*cos(estimate0))
        count += 1
    } while fabs(estimate1 - estimate0) > error && count < maxCount
    //if count >= maxCount {
        //fatalError("Exceeded maxCount in meanToEccetricAnomaly")
        //print("Wow, what is wrong with this body?")
    //}
    if showEccentricAnomalyCount {
        print("eccentric anomaly count = \(count)")
    }
    return estimate1
}

// Convert eccentric anomaly to true anomaly.
func eccentricToTrueAnomaly (eccentricAnomaly: Double, eccentricity: Double) -> Double {
    2.0*atan2(sin(eccentricAnomaly/2.0)*sqrt(1.0 + eccentricity),
                     cos(eccentricAnomaly/2.0)*sqrt(1.0 - eccentricity));
}

// Convert true anomaly to mean anomaly.
func trueToMeanAnomaly (trueAnomaly: Double, eccentricity: Double) -> Double {
    eccentricToMeanAnomaly(
        eccentricAnomaly: trueToEccentricAnomaly(trueAnomaly: trueAnomaly,
                                                 eccentricity: eccentricity),
        eccentricity: eccentricity)
}

// Convert true anomaly to eccentric anomaly.
func trueToEccentricAnomaly (trueAnomaly: Double, eccentricity: Double) -> Double {
    atan2(sqrt(1.0 - eccentricity*eccentricity)*sin(trueAnomaly),
                 eccentricity + cos(trueAnomaly));
}

// Convert eccentric anomaly to mean anomaly.
func eccentricToMeanAnomaly (eccentricAnomaly: Double, eccentricity: Double) -> Double {
    eccentricAnomaly - eccentricity*sin(eccentricAnomaly);
}
