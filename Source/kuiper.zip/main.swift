//
//  main.swift
//  Minor Planets.
//
//  Created by Thomas Wetmore on 8/21/2014.
//  Last changed on 6/18/2022.
//  Copyright (c) 2014-2022 DeadEnds Software. All rights reserved.
//

import Foundation

// This is the main program in the Xcode version.

// Program switches.
let getBruteForceDistances = true
let getObservationBias = false
let buildBalancedTree = true
let buildUnbalancedTree = true
let useBalancedTree = true
let useUnbalancedTree = false
let showBalancedTree = false
let showUnbalancedTree = false
let showObjectsAndPositions = false
let showBruteForceDistances = false
let runUnitTests = false
let showNearestDistances = false
let showPeriods = false
let plotSemimajorAxes = false
let runningInPlayground = false
let showPlutoXYZ = false
let showEccentricAnomalyCount = false
let runMatrixTest = false
let mainAsteroidBelt = false
let nearestNeighborCheck = true
let secondNearestNeighborCheck = true
let differentNearestNeighborCheck = true
let findNumberOfPairs = true
let compareNearestNeighborMethods = false
let useRandomFilter = false
let randomFilterFraction = 0.01
let showTreeDensities = false
let treeSearchTracing = false

// This is the entry point for the main program in the Mac version. Comment this out in
// the Playgrounds version because there the main entry point is in the App structure which
// is not yet used on the Mac version.
mainFunction()

// The main function.
func mainFunction() {
    // Run various checks when requested. These are left over tests from development.
    if runUnitTests {
        testAnomaly()  // Does sanity checks on anomaly computations.
        testTime()     // Does sanity checks on AstroTime class.
    }
    if runMatrixTest {
        testMatrix()   // Does sanity check on Matrix multiplication.
    }

    // Get path to a Minor Planet Center orbit file. In the Swift Playground version the file
    // is in the main Bundle. In the Xcode version it is in the file system.
    let path: String
    if runningInPlayground {  // Running on the iPad under Swift Playgrounds.
        if let filePath = Bundle.main.path(forResource: "distant03222021", ofType: "txt") {
            path = filePath
            print("path exists")
        } else {
            print("Path does not exist.")
            return
        }
    } else {  // Running under Xcode on the Mac.
        // File with distant objects current to 2/26/2022.
        //path = "/Users/ttw4/Desktop/Development/Astronomy/distant02262022.txt"
        // File with distant objects current to 12/23/2023.
        path = "/Users/ttw4/Desktop/Development/Astronomy/distant12232023.txt"
        // Would prefer to read the file out of the main bundle, but doesn't work.
        //path = Bundle.main.path(forResource: "distant06162022", ofType: "txt")!
        // Master file current in early March 2022. Has 1.18 million bodies.
        //path = "/Users/ttw4/Desktop/Development/Astronomy/mpcorb_extended.dat.txt"
        // Special file that includes Pluto to check coordinates with other web sites.
        //path = "/Users/ttw4/Desktop/Development/Astronomy/plutoPlusTwo.txt"
    }

    // Create AstroBodies from the MPC orbit file, then set their heliocentric coordinates.
    print("\(logTime()): Reading the MPC orbit file at \(path).")
    // Read the MPC orbit file and get the AstroBodies defined within it.
    var bodies = getMPCBodiesVersionTwo(path: path)
    print("\n\(logTime()): There are \(bodies.count) bodies in the file.")
    // Get the current time. Heliocentric coordinates are computed for this time.
    let time = AstroTime.now()
    print("\(logTime()): Positions computed at \(time).")

    // Filter orbital values for Kuiper belt objects.
    var (minLength, maxLength, maxInclination) = (25.0, 65.0, degreesToRadians(degrees: 90))
    // Filter orbital values for main asteroid belt.
    if mainAsteroidBelt {
        (minLength, maxLength, maxInclination) = (2.1, 3.3, degreesToRadians(degrees: 20))
    }

    // Filter AstroBodies to those that meet orbital requirements.
    print("\(logTime()): Filtering bodies to chosen orbital parameters.")
    bodies = bodies.filter {
        $0.semimajorAxis >= minLength && $0.semimajorAxis <= maxLength &&
        $0.inclination <= maxInclination
    }
    print("\(logTime()): There are \(bodies.count) filtered bodies")

    // Map AstroBodies into bodies with heliocentric coordinates.
    print("\(logTime()): Computing heliocentric coordinates.")
    bodies = bodies.map {
        var body = $0
        body.setHeliocentric(time: time)
        return body
    }

    // Filter AstroBodies by randomly removing a fraction.
    if useRandomFilter {
        print("\(logTime()): Run randomizing filter.")
        bodies = bodies.filter { _ in
            randomFilter(fraction: randomFilterFraction)
        }
        print("\(logTime()): There are \(bodies.count) randomized bodies.")
    }

    // Show coordinates of Pluto as sanity check on setHeliocentric function.
    if showPlutoXYZ {
        bodies.forEach {
            if $0.name == "(134340) Pluto" {  // Search for Pluto's 'designation string'.
                let p = $0.position
                print("\(logTime()): Pluto's position: x=\(p.x.format(4)),y=\(p.y.format(4)),z=\(p.z.format(4))")
            }
        }
    }

    // Print table of bodies and their positions.
    if showObjectsAndPositions {
        print("\n\(logTime()): Bodies processed with positions and distances at time \(time):")
        for body in bodies {
            print("\(logTime()): \(body.name) at \(body.position), distance \(body.position.length.format(2))",
                  terminator:"")
            print(", semimajor axis \(body.semimajorAxis.format(2))")
        }
    }

    // Find difference between current radius vectors and semimajor axes. This shows observation
    // bias in the data (closer objects are easier to find).
    if getObservationBias {
        var lengthDiff = 0.0
        bodies.forEach {
            lengthDiff += $0.semimajorAxis - $0.position.length
        }
        print("\(logTime()): Value of lengthDiff is \(lengthDiff.format(3)).")
        print("\(logTime()): Average observation bias is \((lengthDiff/Double(bodies.count)).format(3)).")
    }


    // Create balanced KD3Tree.
    var balanced: KD3Tree<AstroBody>?
    if buildBalancedTree || useBalancedTree {
        print("\(logTime()): Building balanced search tree.")
        balanced = balancedTree(objects: bodies)
        if showBalancedTree {
            if let balanced = balanced {
                print("\(logTime()): Contents of the balanced tree:")
                print("\(logTime()): \(balanced.description)")
            } else {
                print("\(logTime()): Error: balanced tree not be created.")
            }
        }
    }

    // Create unbalanced KD3Tree based on the order in the MPC file.
    var unbalanced: KD3Tree<AstroBody>?
    if buildUnbalancedTree || !useBalancedTree || useUnbalancedTree {
        print("\(logTime()): Builing unbalanced search tree.")
        unbalanced = KD3Tree<AstroBody>(objects: bodies)
        if showUnbalancedTree {
            if let unbalanced = unbalanced {
                print("\(logTime()): Contents of unbalanced tree:")
                print("\(logTime()): \(unbalanced.description)")
            } else {
                print("\(logTime()): Error: unbalanced tree not created.")
            }
        }
    }

    // Choose the tree to test.
    let tree: KD3Tree = useBalancedTree ? balanced! : unbalanced!
    let treeType = useBalancedTree ? "balanced" : "unbalanced"
    print("\(logTime()): Using the \(treeType) tree.")

    // Find nearest neighbors by brute force; results can be used to test KD3 algorithms.
    var bruteForceBodies = [AstroBody]()
    if getBruteForceDistances {
        print("\(logTime()): Finding brute force nearest neighbors.")
        bruteForceBodies = bruteForce(bodies: bodies, showDistances: showBruteForceDistances)
    }

    // Find nearest neighbors of each AstroBody and check it is itself.
    if nearestNeighborCheck {
        print("\(logTime()): Check nearestNeighbor: bodies must be their own nearest neighbors.")
        var allSame = true
        var comparisons = 0
        bodies.forEach {
            let nearBody = tree.nearestNeighbor(point: $0.position)
            comparisons += tree.visits
            if $0 != nearBody {
                print("\(logTime()): Error: \($0) and \(nearBody!) are not the same")
                allSame = false
            }
        }
        print("\(logTime()): Number of comparisons: \(comparisons).")
        if allSame {
            print("\(logTime()): Success: nearest neighbors are all themselves.")
        } else {
            print("\(logTime()): Failure: nearest neighbors are not all themselves.")
        }
    }

    // Find the two nearest neighbors to each AstroBody and check that the first is itself. If the
    // brute force nearest neighbors are available, check that second matches the brute force result.
    var k2nearBodies = [AstroBody]()
    if secondNearestNeighborCheck {
        print("\(logTime()): Check nearestKNeighbors to find two nearest neighbors.")
        var pairs = [AstroBody : AstroBody]()  // Map for finding nearest neighbor pairs.
        var distanceSum = 0.0
        var comparisons = 0
        var allSame = true
        k2nearBodies = [AstroBody]()
        var distances = [Double]()
        bodies.forEach {
            // Get two nearest neighbors and their distances.
            let (neighbors, neighborDistances) = tree.kNearestNeighbors(k: 2, point: $0.position)
            comparisons += tree.visits
            // Check that first is the body itself.
            if $0 != neighbors[0] {
                print("\(logTime()): Yikes: \($0) and \(neighbors[0]) are not the same!")
                allSame = false
            }
            distances.append(neighborDistances[1])
            distanceSum += neighborDistances[1]
            k2nearBodies.append(neighbors[1])
            pairs[$0] = neighbors[1]
        }
        if allSame {
            print("\(logTime()): Success: nearest neighbors are all themselves.")
        } else {
            print("\(logTime()): Failure: nearest neighbors are not all themselves.")
        }

        print("\(logTime()): Number of comparisons: \(comparisons)")
        print("\(logTime()): Average nearest neighbor distance: \((distanceSum/Double(bodies.count)).format(9)) au")
    }

    // If brute force neighbors are available, be sure they are the same as the second nearest
    // neighbor. Any differences indicate errors in the nearestKNeighbor function.
    if getBruteForceDistances && secondNearestNeighborCheck {
        var numErrors = 0
        if bruteForceBodies.count == k2nearBodies.count {
            for i in 0 ..< bruteForceBodies.count {
                let o = bodies[i]
                let b = bruteForceBodies[i]
                let k = k2nearBodies[i]
                if b != k {
                    numErrors += 1
                    print("\(logTime()): Error: \(o.name) differs from \(b.name) (\((o.position - b.position).length.format(3))) is not \(k.name) (\((o.position - k.position).length.format(3)))")
                }
            }
        } else {
            numErrors += 1
            print("\(logTime()): Error: Arrays have different lengths: \(bruteForceBodies.count) and \(k2nearBodies.count)")
        }
        if numErrors == 0 {
            print("\(logTime()): Success: second nearest neighbors match brute force neighbors.")
        }
    }

    // This section uses the nearest different neighbor method to find the nearest neighbors.
    var nearestBodies = [AstroBody]()
    var distances = [Double]()
    var distanceSum = 0.0
    nearestBodies = [AstroBody]()
    if differentNearestNeighborCheck {
        print("\(logTime()): Check nearestDifferntNeighbor to find nearest neighbors.")
        var pairs = [AstroBody : AstroBody]()  // Map holding nearest neighbor pairs.
        var comparisons = 0
        var nearComparisons = 0  // Number of times decending predicted branch.
        var farComparisons = 0  // Number of times decending unpredicted branch.
        for body in bodies {
            let nearObject = tree.nearestDifferentNeighbor(point: body.position, tracing: treeSearchTracing)
            if treeSearchTracing {
                print(tree.trace)
            }
            comparisons += tree.visits
            nearComparisons += tree.nearVisits
            farComparisons += tree.farVisits
            nearestBodies.append(nearObject!)
            let distance = (body.position - nearObject!.position).length
            distances.append(distance)
            distanceSum += distance
            pairs[body] = nearObject
        }
        print("\(logTime()): Average nearest neighbor distance: \((distanceSum/Double(bodies.count)).format(9)) au")
        print("\(logTime()): Number of comparisons: \(comparisons) (near: \(nearComparisons), far: \(farComparisons)).")

        // If brute force numbers are available, compare results of the two algorithms.
        if getBruteForceDistances {
            var numErrors = 0
            if bruteForceBodies.count == nearestBodies.count {
                for i in 0 ..< bruteForceBodies.count {
                    let o = bodies[i]
                    let b = bruteForceBodies[i]
                    let k = nearestBodies[i]
                    if b != k {
                        numErrors += 1
                        print("\(logTime()): Error: \(o.name) differs from \(b.name) (\((o.position - b.position).length.format(3))) is not \(k.name) (\((o.position - k.position).length.format(3)))")
                    }
                }
            } else {
                numErrors += 1
                print("\(logTime()): Error: Arrays have different lengths: \(bruteForceBodies.count) and \(nearestBodies.count)")
            }
            if numErrors == 0 {
                print("\(logTime()): Success: nearest unique neighbors match brute force neighbors.")
            }
        }

        // Find number of pairs of bodies that are their own nearest neighbors.
        if findNumberOfPairs {
            print("\(logTime()): Starting to find the pairs.")
            var numberInPairs = 0
            for body in pairs.keys {
                if pairs[pairs[body]!]! == body {
                    numberInPairs += 1
                }
            }
            print("\(logTime()): Number of objects in pairs: \(numberInPairs)")
        }
    }

    // Compare list of k2 nearest neighbors and nearest different neighbors and show differences.
    if compareNearestNeighborMethods {
        print("\(logTime()): Checking for differences between two nearest neighbor methods.")
        var numErrors = 0
        if nearestBodies.count == k2nearBodies.count {
            for i in 0 ..< nearestBodies.count {
                let o = bodies[i]
                let b = k2nearBodies[i]
                let k = nearestBodies[i]
                if b != k {
                    numErrors += 1
                    print("\(logTime()): Error: \(o.name) differs from \(b.name) (\((o.position - b.position).length.format(3))) is not \(k.name) (\((o.position - k.position).length.format(3)))")
                }
            }
        } else {
            numErrors += 1
            print("\(logTime()): Error: the arrays have different lengths")
        }
        if numErrors == 0 {
            print("\(logTime()): Success: the second nearest neighbors match the nearest different neighbors.")
        }
        print("\(logTime()): Done running difference check.")
    }

    // Sort the distances and remove duplicates.
    distances.sort() {$0 < $1}
    var newDistances = [Double]()
    var check = 0.0
    var num = 0
    var den = 0
    for d in distances {
        den += 1
        if d != check {
            newDistances.append(d)
            check = d
            num += 1
        }
    }
    print("\(logTime()): num/den = \(num)/\(den) = \((Double(num)/Double(den)).format(4))")

    // Show the nearest distances.
    if showNearestDistances {
        print("\(logTime()): Nearest distances (au), sorted closest to furthest:")
        print("\(logTime()): There are \(newDistances.count) unique distances")
        newDistances.forEach {
            print("\(logTime()): \($0.format(3)), ", terminator: "")
        }
        print("")
        print("\(logTime()): Before sort: \(distances.count); after sort: \(newDistances.count)")
    }

    // Show the median distance.
    print("\(logTime()): Median distance: \(newDistances[newDistances.count/2].format(9)) au.")

    // Show the periods. The orbital periods of plutinos cluster around 247.3 years (1.5 × Neptune's
    // orbital period), varying by at most a few years from this value.
    if showPeriods {
        var periods = [Double]()
        for body in bodies {
            periods.append(body.period)
        }
        periods.sort() { $0 < $1 }
        for period in periods {
            print("\(logTime()): \(period.format(3)), ", terminator: "")
        }
        // Put each period into a map from year to number.
        var yearMap = [Int : Int]()
        for period in periods {
            let year = Int(period)
            if let count = yearMap[year] {
                yearMap[year] = count + 1
            } else {
                yearMap[year] = 1
            }
        }
        var years = [Int]()
        for year in yearMap.keys {
            years.append(year)
        }
        years.sort() { $0 < $1 }
        for year in 1...100000 {
            if yearMap[year] != nil {
                print("\(logTime()): \(year)\t\(yearMap[year]!)")
            }
        }
    }
    // Plot semimajor axes.
    if plotSemimajorAxes {
        var map = [Int : Int]()
        // Put semimajor axis counts into buckets one tenth of an AU in size.
        for body in bodies {
            let key = Int(body.semimajorAxis*10)
            if let count = map[key] {
                map[key] = count + 1
            } else {
                map[key] = 1
            }
        }
        for size in 200...800 {  // Show bucket sizes from 20 to 80 AU.
            if let count = map[size] {
                print("\(logTime()): \(size)\t\(count)")
            }
        }
    }
    print("\(logTime()): Average nearest neighbor distance: \((distanceSum/Double(bodies.count)).format(9)) au.")

    if showTreeDensities {
        print("\(logTime()): Starting to compute density of tree.")
        let densities = tree.density()
        for density in densities {
            print("\(density)")
        }
        print("\(logTime()): Done computing density.")
    }
}

// Find nearest neighbors using the brute force, n-squared algorithm.
func bruteForce (bodies: [AstroBody], showDistances: Bool = false) -> [AstroBody] {
    var nearBodies = [AstroBody]()  // Nearest neighbors, one to one, with input bodies.
    var nearDistances = [Double]()  // Distances, one to one, to nearest neighbors.
    var distanceSum = 0.0  // Sum of nearest neighbor distances.
    var comparisons = 0  // Number of comparisons used to find nearest neighbors.
    // Find the nearest AstroBody to each AstroBody and the distance between them.
    // Uses the n-squared algorithm.
    for i in 0 ..< bodies.count {
        var nearestDistance = Double.infinity
        var nearestBody: AstroBody? = nil
        for j in 0 ..< bodies.count {
            if i != j {
                comparisons += 1
                let distance = (bodies[i].position - bodies[j].position).length
                if distance < nearestDistance {
                    nearestBody = bodies[j]
                    nearestDistance = distance
                }
            }
        }
        nearBodies.append(nearestBody!)
        nearDistances.append(nearestDistance)
        distanceSum += nearestDistance
    }
    // Show average brute force nearest neighbor distance and number of comparisons.
    print("\(logTime()): Average nearest neighbor distance: \((distanceSum/Double(bodies.count)).format(9)) au.")
    print("\(logTime()): Number of brute force comparisons: \(comparisons).")
    if !showDistances {
        return nearBodies
    }
    // Print the brute force nearest neighbors.
    print("\nBrute Force Nearest Neighbors")
    if bodies.count == nearBodies.count {
        for i in 0 ..< bodies.count {
            print("\(logTime()): \(bodies[i].name) is nearest \(nearBodies[i].name) with distance \(nearDistances[i].format(4))")
        }
    }
    return nearBodies
}

// Test the mean, eccentric, and true anomaly functions, going one way and back the other.
func testAnomaly () {
    var M = 0.618830048239492  // mean anomaly.
    let e = 0.2474562  // eccentricity.
    var E = meanToEccentricAnomaly(meanAnomaly: M, eccentricity: e)  // eccentric anomaly.
    let T = eccentricToTrueAnomaly(eccentricAnomaly: E, eccentricity: e)  // true anomaly.
    print("M = \(M)  E = \(E)  T = \(T)");
    E = trueToEccentricAnomaly(trueAnomaly: T, eccentricity: e)  // eccentric anomaly.
    M = eccentricToMeanAnomaly(eccentricAnomaly: E, eccentricity: e)  // mean anomaly.
    print("T = \(T)  E = \(E)  M = \(M)");
}

// Test for the AstroTime class.
func testTime () {
    let today = AstroTime.now()
    print("\(today)")
    let julian = today.toJulian()
    print("julian: \(julian)")
    let newToday = AstroTime(julian: julian)
    print("\(newToday)")
    var testTime = AstroTime.validTime(year: 2010, month: 10, day: 10, hour: 10, minute: 10, second: 10)
    print("\(String(describing: testTime))")
    testTime = AstroTime.validTime(year: 2010, month: 10, day: 10, hour: 25, minute: 10, second: 10)
    print("\(String(describing: testTime))")
    testTime = AstroTime.validTime(year: 2010, month: "August", day: 10)
    print("\(String(describing: testTime))")
    testTime = AstroTime.validTime(year: 2010, month: "AAUGUUS", day: 10)
    print("\(String(describing: testTime))")
}

// Test the Matrix class.
func testMatrix() {
    var test = Matrix.identity * Matrix.identity
    print(test)
    test = Matrix.identity * Matrix.identity.transpose()
    print(Matrix.identity.transpose())
    print(test)
}

// Random Number filtering function.
func randomFilter(fraction: Double) -> Bool {
    let randomNumber = Double.random(in: 0.0 ... 1.0)
    return randomNumber < fraction
}
