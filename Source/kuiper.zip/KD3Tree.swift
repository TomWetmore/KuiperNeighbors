//
//  KD3Tree.swift
//
//  Created by Thomas Wetmore on 9/7/2014.
//  Last changed on 3/17/2022.
//  Copyright (c) 2014-2022 DeadEnds Software. All rights reserved.
//
// This file defines a public protocol, a public class, four private classes and a public function:
//
// Positioned -- public protocol that Objects in KD3Trees must meet:
//   name: String { get } -- name of the Object.
//   position: Vector { get } -- position of the Object in 3-space.
//
// KD3Tree<Object: Positioned> : CustomStringConvertible -- The only class with a public interface.
//   The public API consists of two properties, two initializers and four methods:
//
//   visits: Int { get } -- used by the most recent neighbor calculation.
//   description: String { get } -- Indented string showing contents of the KD3Tree.
//   init() -- Create an empty KD3Tree.
//   init(objects: [Object]) -- Create a KD3Tree and insert an array of Objects into it.
//   insert(_ object: Object) -- Insert an Object into this KD3Tree.
//   nearestNeighbor(point: Vector) -> Object? -- Return nearest Object to a point.
//   kNearestNeighbors(k: Int, point: Vector) -> ([Object], [Double]) -- Return k nearest Objects
//       and their and distances to a point.
//   nearestDifferentNeighbor(point: Vector) -> Object? -- Return nearest Object to a point that
//       does not occupy the point.
//
// balancedTree<Object: Positioned> (objects: [Object]) -> KD3Tree<Object>? -- Public function that
//   takes an array of Objects and returns a balanced KD3Tree containing those Objects.
//
// KD3Node<Object: Positioned> : CustomStringConvertible -- Private class that holds Objects.
// KD3Queue<Object: Positioned> : CustomStringConvertible -- Private class that holds queues of KD3Nodes.
// SortQueueElement<Object> -- Private class used by the balancedTree function.
// SortQueue<Object> -- Private class used by the balancedTree function.

// Protocol implemented by objects with a name and position in three space.
public protocol Positioned {
    var name: String { get }  // Name of object.
    var position: Vector { get }  // Position of object.
}

// Nodes in Cartesian KD3Trees. Generic parameter, Object, must implement Positioned.
private class KD3Node<Object: Positioned> : CustomStringConvertible {

    // Stored Instance Properties:
    let axis: Int  // Axis that splits the children of this KD3Node, 0 for x, 1 for y, 2 for z.
    let object: Object  // Object this KD3Node holds; provides name and position.
    private(set) var left: KD3Node?  // Left child KD3Node of this KD3Node, if it exists.
    private(set) var right: KD3Node?  // Right child KD3Node of this KD3Node, if it exists.

    // Computed Instance Properies:
    var name: String { object.name }  // Name of this node; delegated to object.
    var position: Vector { object.position }  // Position of this node; delegated to object.
    var description: String { "\(axis) \(position) \(name)" }  // Description of this node.

    // Initialize KD3Node with axis and object.
    init (axis: Int, object: Object) {
        self.axis = axis
        self.object = object
    }

    // Create KD3Node from an Object and insert it below this KD3Node; recursive.
    fileprivate func insert (_ object: Object) {
        if object.position[axis] < self.position[axis] {
            if let left = left {
                left.insert(object)
            } else {
                left = KD3Node(axis: (axis + 1)%3, object: object)
            }
        } else {
            if let right = right {
                right.insert(object)
            } else {
                right = KD3Node(axis: (axis + 1)%3, object: object)
            }
        }
    }

    // Get the 'density' of this KD3Node and those below it; used to get visibility on the tree.
    fileprivate func density(level: Int, densities: inout [Int]) {
        while densities.count <= level {  // Grow density array when necessary.
            densities.append(0)
        }
        densities[level] += 1
        if let left = left {
            left.density(level: level+1, densities: &densities)
        }
        if let right = right {
            right.density(level: level+1, densities: &densities)
        }
    }
}

// Cartesian KD3Tree binary search trees.
public class KD3Tree<Object: Positioned> : CustomStringConvertible {

    // Stored Instance Properties.
    private var root: KD3Node<Object>?  // Root of tree. Created first time insert is called.
    private(set) var visits = 0  // Number of nodes visited by the last tree search.
    private(set) var nearVisits = 0  // Number of preferred node visits.
    private(set) var farVisits = 0  // Number of far side node visits.
    private(set) var trace = ""  // Latest search trace, used in one of the searches.
    // NearVisits and farVisits used for debugging and could be removed.
    // Trace is also for debugging and testing and could be removed.

    // Computed Instance Properties:
    public var description: String {  // Indented description of this KD3Tree.
        if let root = root {
            var buf = ""
            addNodeDescription(node: root, indent: "", buf: &buf)
            return buf
        } else {
            return "empty tree"
        }
    }

    // Initialize an empty KD3Tree. Is this needed?
    //init () { }

    // Initialize KD3Tree from Array of Objects. For balanced trees the Array must be presorted.
    init (objects: [Object]) {
        objects.forEach { self.insert($0) }
    }

    // Insert Object into this KD3Tree. Calls recursive insert method on this KDTreeNode's root.
    private func insert (_ object: Object) {
        if let root = root {
            root.insert(object)
        } else {
            root = KD3Node(axis: 0, object: object)
        }
    }

    // Return nearest Object to a point. If the point is the position of an Object in the
    // KD3Tree then that Object is returned.
    func nearestNeighbor (point: Vector) -> Object? {
        var near: KD3Node<Object>? = nil
        var nearDistance = Double.infinity
        visits = 0
        nearestNeighbor(point: point, node: root, near: &near, nearDistance: &nearDistance)
        return near == nil ? nil : near!.object
    }

    // Find the 'density' of this tree. Provides visibility of tree structure.
    func density() -> [Int] {
        var densities = [Int]()  // Number of KD3Nodes at each level.
        if let root = root {
            root.density(level: 1, densities: &densities)
        }
        return densities
    }

    // Recursive function that does the nearest neighbor search.
    private func nearestNeighbor (point: Vector,  // Find nearest neighbor of this point.
                                  node: KD3Node<Object>?,  // Current node in the tree.
                                  near: inout KD3Node<Object>?,  // Nearest object found so far.
                                  nearDistance: inout Double) {  // Nearest distance found so far.
        if let node = node {
            visits += 1
            let axis = node.axis
            // See if current node is the closest so far.
            let distance = (point - node.position).length
            if distance < nearDistance {
                nearDistance = distance
                near = node
                if nearDistance == 0.0 {
                    return
                }
            }
            // Find the side of the axis more likely to hold the neighbor.
            var one: KD3Node<Object>?
            var two: KD3Node<Object>?
            if point[axis] < node.position[axis] {
                one = node.left
                two = node.right
            } else {
                one = node.right
                two = node.left
            }
            // Search the more likely side of the axis.
            nearestNeighbor(point: point,
                            node: one,
                            near: &near,
                            nearDistance: &nearDistance)
            // Search the other side of the axis if it could hold the nearest neighbor.
            if let two = two {
                if abs(point[axis] - node.position[axis]) < nearDistance {
                    nearestNeighbor(point: point,
                                    node: two,
                                    near: &near,
                                    nearDistance: &nearDistance)
                }
            }
        }
    }

    // Return the k nearest neighbor objects and their distances to a point. The points are returned
    // in an array in the order of their distance to the point. If the point is the position of an
    // object in the tree then that object is returned as the first object in the array.
    func kNearestNeighbors (k: Int, // Number of neighbors to find.
                            point: Vector) -> ([Object], [Double]) { // Point searched for.
        var queue = KD3Queue<Object>(size: k)
        visits = 0
        kNearestNeighbors(point: point,
                          node: root,
                          queue: &queue)
        return (queue.objects, queue.distances)
    }

    // Recursive method that does the k nearest neighbors search.
    private func kNearestNeighbors (point: Vector,
                                    node: KD3Node<Object>?,
                                    queue: inout KD3Queue<Object>) {
        if let node = node {
            visits += 1
            let axis = node.axis
            let distance = (point - node.position).length
            queue.insert(node: node, distance: distance)

            // Find the side of the axis more likely to hold the neighbor.
            var one: KD3Node<Object>?
            var two: KD3Node<Object>?
            if point[axis] <= node.position[axis] {
                one = node.left
                two = node.right
            } else {
                one = node.right
                two = node.left
            }
            // Search the more likely side of the axis.
            kNearestNeighbors(point: point,
                              node: one,
                              queue: &queue)
            // Search the other side of the axis if it could also hold nearest neighbors.
            if let two = two {
                if !queue.full || abs(point[axis] - node.position[axis]) < queue.maxDistance {
                    kNearestNeighbors(point: point,
                                      node: two,
                                      queue: &queue)
                }
            }
        }
    }

    // Enum used to instrument code to find the distribution of near vs far moves. Added for
    // debugging and testing.
    enum Side {
        case near // Side of axis that should contain next nearer Object.
        case far  // Side of axis less likely to contain next nearer Object.
    }



    // Return nearest neighbor Object that does not occupy the same point. The tracing feature
    // traces the descent through the tree during each search.
    func nearestDifferentNeighbor (point: Vector,
                                   tracing: Bool = false) -> Object? {
        var near: KD3Node<Object>? = nil
        var nearDistance = Double.infinity
        visits = 0
        nearVisits = 0
        farVisits = 0
        trace = ""
        nearestDifferentNeighbor(point: point,
                                 node: root,
                                 near: &near,
                                 nearDistance: &nearDistance,
                                 side: .near,
                                 tracing: tracing,
                                 trace: &trace)
        return near == nil ? nil : near!.object
    }

    // Recursive method that does nearest different neighbor search.
    private func nearestDifferentNeighbor (point: Vector,
                                           node: KD3Node<Object>?,
                                           near: inout KD3Node<Object>?,
                                           nearDistance: inout Double,
                                           side: Side,
                                           tracing: Bool,
                                           trace: inout String) {
        if let node = node {
            if side == .near {
                nearVisits += 1
            } else {
                farVisits += 1
            }
            visits += 1
            let axis = node.axis
            var bothSides = false

            // See if the current node is the closest so far.
            let distance = (point - node.position).length
            if distance == 0.0 {
                bothSides = true
            } else if distance < nearDistance {
                if tracing { trace.append("*") }
                nearDistance = distance
                near = node
            }
            // Find the side of the axis more likely to hold the neighbor.
            var one: KD3Node<Object>?
            var two: KD3Node<Object>?
            if point[axis] < node.position[axis] {
                one = node.left
                two = node.right
            } else {
                one = node.right
                two = node.left
            }
            // Search the more likely side of the axis.
            if tracing { trace.append("n(") }
            nearestDifferentNeighbor(point: point,
                                     node: one,
                                     near: &near,
                                     nearDistance: &nearDistance,
                                     side: .near,
                                     tracing: tracing,
                                     trace: &trace)
            if tracing { trace.append(")") }

            // Search the other side of the axis if it could hold neighbors.
            if let two = two {
                if bothSides || abs(point[axis] - node.position[axis]) < nearDistance {
                    if tracing { trace.append("f[")}
                    nearestDifferentNeighbor(point: point,
                                             node: two,
                                             near: &near,
                                             nearDistance: &nearDistance,
                                             side: .far,
                                             tracing: tracing,
                                             trace: &trace)
                    if tracing { trace.append("]") }
                }
            }
        }
    }

    // Recursive method used by the KD3Tree description property.
    private func addNodeDescription (node: KD3Node<Object>,  // Current node to describe.
                                     indent: String,  // Indent level of current node.
                                     buf: inout String) {  // Description accumluation buffer.
        if let child = node.left {
            addNodeDescription(node: child, indent: indent + "  ", buf: &buf)
        }
        buf += indent + node.description + "\n"
        if let child = node.right {
            addNodeDescription(node: child, indent: indent + "  ", buf: &buf)
        }
    }
}

// Instances of this class hold ordered queues of nearest neighbors and their distances.
private class KD3Queue<Object: Positioned>: CustomStringConvertible {

    // Nearest Objects to target point found so far.
    var objects = [Object]()

    // Distances to the nearest Objects.
    var distances = [Double]()

    // Maximum number of nearest neighbors to keep.
    let size: Int

    // True if this KD3Queue is full.
    var full: Bool { objects.count >= size }

    // Max distance from Objects in this KD3Queue to the target point.
    var maxDistance: Double {
        let len = objects.count
        return len == 0 ? Double.infinity : distances[len - 1]
    }

    // String descripiton of this KD3Queue.
    var description: String {
        var buf: String = "["
        var started = false
        for distance in distances {
            if started {
                buf += ", "
            } else {
                started = true
            }
            buf += "\(distance.format(3))"
        }
        buf += "]"
        return buf
    }

    // Initialize this KD3Queue with a maximum size.
    init (size: Int) {
        self.size = size
    }

    // Insert a KD3Node into this KD3Queue if there is room or if the distance is less than
    // the current max.
    func insert (node: KD3Node<Object>, distance: Double) {
        if !full {
            insertDirect(node: node, distance: distance)
        } else if distance < distances[size - 1] {
            objects.removeLast()
            distances.removeLast()
            insertDirect(node: node, distance: distance)
        }
    }

    // Insert an Object and its distance into the queues when it is known there is room.
    private func insertDirect (node: KD3Node<Object>, distance: Double) {
        // First add to the ends of the Arrays.
        distances.append(distance)
        objects.append(node.object)
        // Then swap the new elements into their ordered position.
        var done = false
        for i in stride(from: distances.count - 2, through: 0, by: -1) {
            if distance < distances[i] {
                distances[i + 1] = distances[i]
                objects[i + 1] = objects[i]
            } else {
                distances[i + 1] = distance
                objects[i + 1] = node.object
                done = true
            }
        }
        if !done {
            distances[0] = distance
            objects[0] = node.object
        }
    }
}

// Create a balanced KD3Tree from an array of objects. This is done by presorting the array so
// that a balanced KD3Tree is created when the objects in the array are inserted in order.
public func balancedTree<Object: Positioned> (objects: [Object]) -> KD3Tree<Object>? {

    // Array to hold the objects in proper order to build a balanced KD3Tree.
    var ordered = [Object]()

    // Create the first element with the full array.
    let queue = SortQueue<Object>()
    queue.enqueue(element: SortQueueElement<Object>(axis: 0, objects: objects))

    // Process elements from the queue until the queue is empty.
    while !queue.empty {

        // Remove the first element from the queue and sort its objects around its axis.
        let element = queue.dequeue()
        let axis = element.axis
        element.objects.sort {
            $0.position[axis] < $1.position[axis]
        }

        // Add the median body to the ordered array.
        let mid = element.mid
        let count = element.count
        ordered.append(element.objects[mid])

        // Put what remains of the elements back on the queue.
        if count > 1 {
            let left = Array(element.objects[0 ... mid - 1])
            queue.enqueue(element: SortQueueElement<Object>(axis: (axis + 1)%3, objects: left))
        }
        if count > 2 {
            let right = Array(element.objects[mid + 1 ... count - 1])
            queue.enqueue(element: SortQueueElement<Object>(axis: (axis + 1)%3, objects: right))
        }
    }

    // Return a balanced KD3Tree by by inserting the ordered objects into a new KD3Tree.
    return KD3Tree<Object>(objects: ordered)
}

// Class for the queue elements used to create balanced KD3Trees. This class is only used to
//  support the balancedTree function.
private class SortQueueElement<Object> {

    // Stored properties.
    var axis: Int  // Axis of this element.
    var objects: [Object]  // Array of Objects in this SortQueueElement.

    // Computed properties.
    var count: Int { objects.count }  // Number of Objects in this SortQueueElement.
    var mid: Int { objects.count/2 }  // Index of middle/median Object in this SortQueueElement.

    // Initialize a SortQueueElement.
    init (axis: Int, objects: [Object]) {
        self.axis = axis
        self.objects = objects
    }
}

// Queue used to create balanced KD3Trees.
private class SortQueue<Object> {

    // Stored properties.
    var elements = [SortQueueElement<Object>]()  // Elements making up this SortQueue.

    // Computed properties.
    var empty: Bool { elements.count == 0 }  // Return true if this SortQueue is empty.

    // Add a SortQueueElement to this SortQueue.
    func enqueue (element: SortQueueElement<Object>) {
        elements.append(element)
    }

    // Remove and return a SortQueueElement from this SortQueue.
    func dequeue () -> SortQueueElement<Object> {
        let element = elements[0]
        elements.remove(at: 0)
        return element
    }
}
