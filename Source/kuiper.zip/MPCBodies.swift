//
//  MPCBodies.swift
//  AstronomyKit
//
//  Created by Thomas Wetmore on 8/25/2014.
//  Last changed on 6/18/2022.
//  Copyright (c) 2014-2022 Deadends Software. All rights reserved.
//

import Foundation

// Read a Minor Planet Center orbit file and return its objects as an Array of AstroBodies.
public func getMPCBodies (path: String) -> [AstroBody] {
    var objects = [AstroBody]()
    var count = 0
    if let fileString = try? String(contentsOfFile: path, encoding: String.Encoding.utf8) {
        for line in fileString.components(separatedBy: "\n") {
            if let object = getMPCBody(line: line) {
                objects.append(object)
                count += 1
                if count % 1000 == 0 {
                    print(".", separator: "", terminator: "")
                }
            }
        }
    }
    return objects
}

// This version separates breaking the file into lines with creating the AstroBodies in order
// to time both operations.
public func getMPCBodiesVersionTwo(path: String) -> [AstroBody] {
    var objects = [AstroBody]()
    var lines = [String]()
    if let fileString = try? String(contentsOfFile: path, encoding: String.Encoding.utf8) {
        print("\(logTime()): Breaking file into lines.")
        fileString.components(separatedBy: "\n").forEach { lines.append($0) }
        print("\(logTime()): File has \(lines.count) lines.")
    }
    print("\(logTime()): Creating bodies for each line.")
    var count = 0
    lines.forEach {
        if let object = getMPCBody(line: $0) {
            objects.append(object)
            count += 1
            if count % 1000 == 0 {
                print(".", separator: "", terminator: "")
            }
        }
    }
    return objects
}

// Get type of an MPC object from its type field. This function has not been tested.
func getMPCBodyType (line: String) -> Int? {
    let chars = Array(line.utf16)
    return MPCBodyType(hexLeft: chars[163], hexRight: chars[164])
}

// Build an AstroBody from a line of an MPC orbit file. The line consists of fixed length fields.
// TODO: Convert angles to the Angle struct approach.
func getMPCBody(line: String) -> AstroBody? {

    // Extract properties from the line. First convert line to Array of UTF16 values.
    let chars = Array(line.utf16)
    if chars.count == 0 {
        return nil
    }

    // The orbital elements on the line are five of the six Keplerian elements: semimajor axis,
    // inclination, eccentricity, argument of perihelion, and longitude of ascending node.
    // Instead of true anomaly at epoch the file uses mean anomaly at epoch. Mean anomaly is converted
    // to true anomaly.
    let epoch = extractEpoch(chars, start: 21)  // Date of mean and true anomaly.
    let meanAnomalyAtEpoch = degreesToRadians(degrees: extractDouble(chars, start: 27, end: 35))
    let argPerihelion = degreesToRadians(degrees: extractDouble(chars, start: 38, end: 46))
    let ascendingNode = degreesToRadians(degrees: extractDouble(chars, start: 49, end: 57))
    let inclination = degreesToRadians(degrees: extractDouble(chars, start: 60, end: 68))
    let eccentricity = extractDouble(chars, start: 71, end: 79)
    let semimajorAxis = extractDouble(chars, start: 93, end: 103)
    let trueAnomalyAtEpoch = meanToTrueAnomaly(meanAnomaly: meanAnomalyAtEpoch,
                                               eccentricity: eccentricity)
    let designation = extractString(chars, start: 167, end: 194)

    // Create an AstroBody with the six classic Keplerian elements plus the true anomaly epoch.
    var astroBody = AstroBody(name: designation, mass: 0.0, radius: 0.0)
    astroBody.setElements(semimajorAxis: semimajorAxis,
                          eccentricity: eccentricity,
                          inclination: inclination,
                          longAscendingNode: ascendingNode,
                          argPeriapsis: argPerihelion,
                          epoch: epoch,
                          trueAnomalyAtEpoch: trueAnomalyAtEpoch)
    return astroBody
}

// Return the type code extracted from two characters. This function has not been tested.
private func MPCBodyType (hexLeft: UInt16, hexRight: UInt16) -> Int? {
    let left = convertHexChar(char: hexLeft)
    let right = convertHexChar(char: hexRight)
    if left == nil || right == nil { return nil }
    let type = ((left! & 3) << 4) + right!
    return type
}

// Convert character (UInt16) representing a hex value to its Int value.
private func convertHexChar (char: UInt16) -> Int? {
    // 48 to 57 are '0' to '9', 65 to 70 are 'A' to 'F' and 97 to 102 are 'a' to 'f'.
    switch char {
    case 48...57:  return Int(char) - 48
    case 65...70:  return Int(char) - 65 + 10
    case 97...102: return Int(char) - 97 + 10
    default:       return nil
    }
}

// Extract a Double from a Range in an Array of utf16 (UInt16) values. Start and end are 1-based.
private func extractDouble (_ chars: [UInt16], start: Int, end: Int) -> Double {
    // 46 is '.' and 48 to 57 are '0' to '9'.
    var intPart = 0.0
    var decPart = 0.0
    var pow10 = 10.0
    var left = true
    for index in start - 1 ..< end {
        let char = chars[index]
        if char == 46 {
            left = false
        } else if char >= 48 && char <= 57 {
            let digit = char - 48
            if left {
                intPart = intPart*10.0 + Double(digit)
            } else {
                decPart = decPart + Double(digit)/pow10
                pow10 *= 10.0
            }
        }
    }
    return intPart + decPart
}

// Extract a String from a Range in an Array of utf16 (UInt16) values. Start and end are 1-based.
private func extractString (_ chars: [UInt16], start: Int, end: Int) -> String {
    var result: String = ""
    for index in start - 1 ..< min(end, chars.count) {
        result.append(Character(UnicodeScalar(chars[index])!))
    }
    return result.trimmingCharacters(in: CharacterSet.whitespaces)
}

// Convert MPC representation of date to an AstroTime object. Start is 1-based.
private func extractEpoch(_ chars: [UInt16], start: Int) -> AstroTime {
    // 48 is '0', 57 is '9', 65 is 'A', 75 is 'K'.
    let a = chars[start-1]
    let b = chars[start]
    let c = chars[start+1]
    let d = chars[start+2]
    let e = chars[start+3]
    var year: Int = ((a == 75) ? 2000 : 1900)
    year = year + 10*(Int(b) - 48) + Int(c) - 48
    let month: Int = (Int(d) < 57) ? Int(d) - 48 : Int(d) - 65 + 10
    let day: Int = (Int(e) < 57) ? Int(e) - 48 : Int(e) - 65 + 10
    return AstroTime(year: Int(year), month: month, day: day)
}
